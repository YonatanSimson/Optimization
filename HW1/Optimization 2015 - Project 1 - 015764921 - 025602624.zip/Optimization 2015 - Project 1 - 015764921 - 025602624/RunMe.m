% Main Routine RunMe
% options:  q4, q8, q10, q11, q13, q12, q15, q16, all

Qcase  = 'all';

%2d Gradients on 3 images
if(strcmp(Qcase, 'q4')  || strcmp(Qcase, 'all'))
    Q4
end

%close form LS solution for toy example
if(strcmp(Qcase, 'q8')  || strcmp(Qcase, 'all'))
    Q8
end

%CG on Toy example - with comparision to closed form
if(strcmp(Qcase, 'q10')  || strcmp(Qcase, 'all'))
    Q10
end

%CG with different lambda's for small problem
if(strcmp(Qcase, 'q11')  || strcmp(Qcase, 'all'))
    Q11
end

%comparing norm L1 to norm L2 on 1D example
if(strcmp(Qcase, 'q13')  || strcmp(Qcase, 'all'))
    Q13
end

%L1 regularization with IRLS on small problem
if(strcmp(Qcase, 'q15')  || strcmp(Qcase, 'all'))
    Q15
end

%L1 regularization with IRLS on large problem
if(strcmp(Qcase, 'q16')  || strcmp(Qcase, 'all'))
    Q16
end

